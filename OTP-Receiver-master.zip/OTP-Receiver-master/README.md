# OTP-Receiver
OTP-Receiver

![otp](https://user-images.githubusercontent.com/36407710/83994153-2b3d6b00-a973-11ea-8774-e706967cc4d8.png)
